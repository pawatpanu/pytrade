@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0PyTradeSetup-20260314-224221.exe"
endlocal
